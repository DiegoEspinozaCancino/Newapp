package com.example.newapp;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;

import androidx.annotation.NonNull;

import com.example.newapp.ui.colors.ColorsFragment;
import com.example.newapp.ui.home.HomeFragment;
import com.example.newapp.ui.settings.SettingsFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Main_navbar extends AppCompatActivity {
    private HomeFragment firstFragment = new HomeFragment();
    private ColorsFragment secondFragment = new ColorsFragment();
    private SettingsFragment thirdFragment = new SettingsFragment();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate((savedInstanceState));
        setContentView(R.layout.navbar_layout);
        BottomNavigationView navigation = findViewById(R.id.botton_nav);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);


    }

    private final BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()){
                case R.id.homeFragment:
                    loadFragment(firstFragment);
                    return true;
                case R.id.colorsFragment:
                    loadFragment(secondFragment);
                    return true;
                case R.id.settingsFragment:
                    loadFragment(thirdFragment);
                    return true;


            }
            return false;
        }
    };

    public void loadFragment(Fragment fragment){
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frame1, fragment);
        transaction.commit();
    }
}